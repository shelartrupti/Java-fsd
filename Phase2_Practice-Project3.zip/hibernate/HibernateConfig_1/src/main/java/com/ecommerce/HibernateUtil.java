package com.ecommerce;

import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class HibernateUtil {

    private static final SessionFactory sessionFactory;

    static {
        try {
            // Creating the StandardServiceRegistry from hibernate.cfg.xml
            StandardServiceRegistry standardRegistry = new StandardServiceRegistryBuilder()
                    .configure("hibernate.cfg.xml").build();

            // Creating MetadataSources from the StandardServiceRegistry
            Metadata metaData = new MetadataSources(standardRegistry).getMetadataBuilder().build();

            // Building the SessionFactory from the Metadata
            sessionFactory = metaData.getSessionFactoryBuilder().build();
        } catch (Throwable th) {
            // Handle errors during initialization
            throw new ExceptionInInitializerError(th);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }
}
