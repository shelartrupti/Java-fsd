package com.ecommerce;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name = "eproduct")
public class EProduct implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "price")
    private Double price;

    @Column(name = "date_added")
    private java.sql.Timestamp dateAdded;

    // Constructors, getters, setters, and other methods

    public EProduct() {
        // Default constructor
    }

    public EProduct(String name, Double price) {
        this.name = name;
        this.price = price;
        // Assuming you want to set the dateAdded to the current timestamp by default
        this.dateAdded = new java.sql.Timestamp(System.currentTimeMillis());
    }

    // Getter and setter methods for other fields

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public java.sql.Timestamp getDateAdded() {
        return dateAdded;
    }

    public void setDateAdded(java.sql.Timestamp dateAdded) {
        this.dateAdded = dateAdded;
    }
}
