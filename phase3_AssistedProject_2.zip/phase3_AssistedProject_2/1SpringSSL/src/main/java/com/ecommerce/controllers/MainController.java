package com.ecommerce.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
class MainController {

         private final Repository repository = null;
         
         @RequestMapping("/")
          @ResponseBody
          public <under> String index() {
               

        	 
            String is;
            return ("this is running under SSL");
			
          }

}
